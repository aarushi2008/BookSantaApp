import firebase from 'firebase';
require('@firebase/firestore')

const firebaseConfig = {
  apiKey: "AIzaSyB9kJvEUQKhQ_JcD7EhKbpK_JtUC0xlOeg",
  authDomain: "booksanta-5f058.firebaseapp.com",
  projectId: "booksanta-5f058",
  storageBucket: "booksanta-5f058.appspot.com",
  messagingSenderId: "69595867399",
  appId: "1:69595867399:web:1ea7cd63b96c0c29d0bda2"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

export default firebase.firestore();
